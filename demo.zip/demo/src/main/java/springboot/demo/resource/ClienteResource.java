package springboot.demo.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import springboot.demo.domain.Cliente;
import springboot.demo.domain.Endereco;
import springboot.demo.service.ClienteService;

@RestController
@RequestMapping("/api/v1/clientes")
public class ClienteResource {

    @Autowired
    private ClienteService clienteService;

    @GetMapping
    public ResponseEntity<List<Cliente>> obterTodosClientes() {

        List<Cliente> clientes = clienteService.findAll();

        if (clientes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(clientes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cliente> obterPorId(@PathVariable("id")Long id) {

        Cliente cliente;
        try{
            cliente = clienteService.findById(id);
            return ResponseEntity.ok(cliente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
        
    }

    @PostMapping
    public Cliente saveCliente(@RequestBody Cliente cliente) {
        clienteService.save(cliente);
        return cliente;
    }

    @PutMapping
    public ResponseEntity<Cliente> atualizarCliente(@RequestBody Cliente cliente) {
        try {
            clienteService.findById(cliente.getId());
            clienteService.update(cliente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(cliente);
    }

    @PatchMapping("/{id}/endereco") 
    public ResponseEntity<Cliente> atualizarEndereco (@PathVariable ("id") Long id, @RequestBody Endereco endereco) {
        Cliente cliente;
        try {
            cliente = clienteService.findById(id);
            cliente.setEndereco(endereco);
            clienteService.update(cliente);

            return ResponseEntity.ok().body(cliente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }      
    }      
    
    @DeleteMapping("/{id}") 
    public ResponseEntity<?> deletarClientePorId(@PathVariable("id") Long id) {
        try {
            clienteService.deletePorID(id);
            clienteService.findById(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    } 
}
