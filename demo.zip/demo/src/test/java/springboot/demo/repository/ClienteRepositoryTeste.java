package springboot.demo.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import springboot.demo.domain.Cliente;
import springboot.demo.domain.Endereco;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

@DataJpaTest
public class ClienteRepositoryTeste {
    
    @Autowired
    private ClienteRepository clienteRepository;

    @Test
    public void testAddCliente() {

        Endereco endereco = new Endereco("Av.Goias", "Central", "Goiania", "GO", "74000000");
        Cliente cliente = new Cliente("Jorge", "0908070605", "jorge@hotmail.com", endereco);

        Cliente saveCliente = clienteRepository.save(cliente);
        assertThat(saveCliente).isNotNull();
        assertThat(saveCliente.getId()).isGreaterThan(0);

        assertThat(saveCliente.getEndereco()).isNotNull();
        assertThat(saveCliente.getEndereco().getId()).isGreaterThan(0);
    }
}
